const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
let currMonth = new Date().getMonth() + 1;

function get(elem) {
    return document.getElementById(elem);
}

function drawCalendar() {
    let table = document.createElement("table");
    table.id = "calendar";
    let thead = document.createElement("thead");
    let td = document.createElement("td");
    thead.appendChild(td);
    for (let i = 1; i <= 31; i++) {
        let td = document.createElement("td");
        td.innerText = i;
        thead.appendChild(td);
    }
    table.appendChild(thead);
    if ("undefined" !== typeof calendarData["flag"]) {
        get("calendar").className = "calendar flagText2";
        get("calendar").innerHTML = "Flag: " + calendarData["flag"];
        setTimeout(function() {
            get("calendar").className = "calendar flagText1";
        }, 50);
        setTimeout(function() {
            get("calendar").className = "calendar flagText2";
        }, 100);
        return;
    }
    for (let i = 0; i <= Object.keys(calendarData).length - 1; i++) {
        if ("undefined" === typeof calendarData["user_" + i]) {
            continue;
        }
        let tr = document.createElement("tr");
        let td = document.createElement("td");
        td.innerText = calendarData["user_" + i].name;
        td.className = "noBorder";
        tr.appendChild(td);
        for (let j = 1; j <= 31; j++) {
            let td = document.createElement("td");
            td.style.background = calendarData["user_" + i]['days'][months[currMonth - 1]] && calendarData["user_" + i]['days'][months[currMonth - 1]].indexOf(j - 1) > -1 ? "#b00" : "";
            tr.appendChild(td);
        }
        table.appendChild(tr);
    }
    get("calendar").innerHTML = "";
    get("calendar").appendChild(table);
    get("month").innerText = months[currMonth-1];
}

function goPrev() {
    if (1 < currMonth) {
        currMonth--;
        drawCalendar();
    }
}

function goNext() {
    if (12 > currMonth) {
        currMonth++;
        drawCalendar();
    }
}

const token = "biD%NOhd_3f3i7y98h.od43fhg%ifbc43yf";
